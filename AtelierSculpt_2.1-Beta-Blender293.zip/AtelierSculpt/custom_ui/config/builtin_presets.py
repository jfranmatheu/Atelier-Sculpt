from os.path import realpath, dirname, join

builtin_sculpt_preset_jfran = join(dirname(realpath(__file__)), "builtin_sculpt_preset_jfran.json")
