from os.path import realpath, dirname, join

default_sculpt_config = join(dirname(realpath(__file__)), "default_sculpt_config.json")
